import { U as Trigger, l as OutboundMessage } from "./intake-DlEkHhs0.js";
import { n as SourceContext, t as SourceKind } from "./kind-Cjzylji7.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
/** The `from` identity the Channel writes into every reply; a message with this sender never becomes a Trigger. */
declare const INBOX_AGENT_FROM = "dsh-superagent";
declare const ConfigSchema: z.ZodObject<{
  root: z.ZodDefault<z.ZodString>;
  agentName: z.ZodDefault<z.ZodString>;
  conversations: z.ZodDefault<z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    listen: z.ZodEnum<{
      mentions: "mentions";
      all: "all";
    }>;
  }, z.core.$strict>>>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
type InboxConfig = z.infer<typeof ConfigSchema>;
/** One message file as its JSON; unknown members are kept out of the way by the loose shape. */
declare const MessageSchema: z.ZodObject<{
  id: z.ZodString;
  from: z.ZodString;
  text: z.ZodString;
  at: z.ZodOptional<z.ZodString>;
  bot: z.ZodDefault<z.ZodBoolean>;
  to: z.ZodOptional<z.ZodString>;
  thread: z.ZodOptional<z.ZodString>;
  reply_to: z.ZodOptional<z.ZodString>;
  url: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
type InboxMessage = z.infer<typeof MessageSchema>;
/**
 * The Trigger of one inbox message; the agent's own replies produce none. The Trigger id and the Thread id derive from
 * the conversation and message ids, so re-reading a file is safe, and the reply address carries the inbox root (`dir`)
 * and the Thread root (`thread`), so the Channel needs no configuration lookup and every reply joins its Thread.
 */
declare function inboxTrigger(message: InboxMessage, conversation: string, at: string, config: InboxConfig): Trigger | undefined;
/**
 * One polling round: reads each configured conversation's waiting messages, hands every one to the Engine, and moves
 * the processed file into `in/done/` only after `receive` has resolved. A file that is missing, malformed or written by
 * the agent stays where it is and counts as unreadable, so a stray file is visible in the Source's health instead of
 * vanishing. Stable Trigger ids make a replayed round harmless.
 */
declare function pollInbox(ctx: SourceContext, config: InboxConfig, signal: AbortSignal): Promise<{
  read: number;
  unreadable: number;
}>;
declare const inboxKind: SourceKind<InboxConfig>;
/**
 * Sends one reply as a JSON file in the conversation's `out/` folder, named by the message id, so a retried send finds
 * the file already there and succeeds without writing twice. The reply names the message it answers (`to`), the Thread
 * root it belongs to (`thread`), and the direct parent (`reply_to`), which keeps it inside the thread context. File
 * delivery never becomes permanent (`gone`); a write failure throws for the Outbox to retry.
 */
declare function sendInbox(_host: Pick<SourceContext, 'commands'>, message: OutboundMessage): Promise<'sent' | 'gone'>;
declare const name = "dsh-superagent-inbox";
declare const inject: string[];
declare function apply(ctx: Context): void;
export { INBOX_AGENT_FROM, InboxConfig, InboxMessage, apply, inboxKind, inboxTrigger, inject, name, pollInbox, sendInbox };